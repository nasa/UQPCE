
Background
+++++++++++

.. _definitions:

Definitions
============

There are a few definitions that the user will need to be familiar with in order 
to correctly use UQPCE and analyze its results.

**Aleatory**
	This is a type of uncertainty due to inherent variation of a parameter, 
	physical system or environment. An example of aleatory uncertainty is 
	atmospheric wind speed. This type of uncertainty is often referred to as 
	irreducible uncertainty.

**Epistemic**
	This is a type of uncertainty due to imperfect knowledge or ignorance of a 
	variable. An example of epistemic uncertainty is an empirically or subject 
	matter expert derived parameter.

**Sobol**
	Sobol indices are global non-linear estimates of sensitivity. In general, 
	the larger a Sobol index, the more sensitive the model is to that term.

Variables
=========
In this section, the variables used by UQPCE will be documented.

Normal Variable
----------------
The equation UQPCE uses for a normal variable is shown below. The support range 
of this variable is [:math:`-\infty`, :math:`\infty`].

.. math::
	f(x) = \frac{1}{\sigma\sqrt{2\pi}} e^{-\frac{(x - \mu)^{2}}{2\sigma^{2}}}
	
where :math:`\mu \in \mathbb{R}` and :math:`\sigma^{2} > 0`

Uniform Variable
-----------------
The equation UQPCE uses for a uniform variable is shown below. The support range 
of this variable is [a, b].

.. math::
	f(x) = \frac{1}{b - a}
	
where :math:`-\infty < a < b < \infty`
	
Beta Variable
--------------
The equation UQPCE uses for a beta variable is shown below. The support range 
of this variable is [a, b].

.. math::
	f(x) = \frac{1}{b - a} \frac{\Gamma(\alpha + \beta)}
	{\Gamma(\alpha) \Gamma(\beta)} 
	\Bigg(\frac{x - a}{b - a}\Bigg)^{\alpha - 1} 
	\Bigg(\frac{b - x}{b - a}\Bigg)^{\beta - 1} 
	
where :math:`\alpha > 0`, :math:`\beta > 0`, and the gamma function 
:math:`\Gamma(n) = (n - 1)!`
	
.. note::
	The implementation of the density function used for this program is the 
	more-common  equation for the beta distribution, while common orthogonal 
	polynomial conventions use a different equation. The user must treat their 
	data according to the above equation.

Exponential Variable
---------------------	
The equation UQPCE uses for an exponential variable is shown below. The support 
range of this variable is [a, :math:`\infty`].

.. math::
	f(x) = \lambda e^{-\lambda (x\ -\ a)}

where :math:`\lambda > 0`

Gamma Variable
---------------
The equation UQPCE uses for a gamma variable is shown below. The support range 
of this variable is [a, :math:`\infty`].

.. math::
	f(x) = \frac{1}{\Gamma(\alpha)\theta^{\alpha}} (x\ -\ a)^{\alpha - 1} 
	e^{-\frac{(x\ -\ a)}{\theta}}

where :math:`\alpha > 0`, :math:`\theta > 0`, and the gamma function :math:`\Gamma(n) = (n - 1)!`

.. _variable:

General Variable
-----------------
This is an option for the user to input a variable that has an arbitrary 
distribution. While this gives the user flexibility, there are some 
requirements the distribution must adhere to:

* The distribution must have numbers plugged in for any parameters.
* The distribution and samples need to be standardized as inputs, as UQPCE 
  currently has no way of standardizing the Variable class distribution and 
  samples.
* The distribution must be continuous.
* The distribution must have a finite integral over its support range.

.. note::
	For many distributions, this general variable option works well. It is, 
	however, possible that the orthogonal polynomials and/or norm squared 
	values for an input equation take significant computational time to converge.


Symbols
========

In the next sections, concepts that UQPCE relies on will be covered. Below are 
the symbols and their meanings.

:math:`X` - the variable basis matrix

:math:`y` - the responses of the system from the ``results.dat`` file

:math:`\hat{y}` - the vector of predicted responses

:math:`y_v` - the responses of the system from the ``verification_results.dat`` file

:math:`\hat{y}_{v}` - the vector of predicted verification responses

:math:`x` - the set of variable values from the ``run_matrix.dat`` file

:math:`\beta` - the coefficients for the surrogate model

:math:`\langle \bf{\Psi}^{2} \rangle` - the multivariate norm squared matrix

:math:`\langle \Psi^{2} \rangle` - the univariate norm squared matrix

:math:`\psi_i` - the :math:`i^{th}` order orthogonal polynomial basis component

:math:`p` - the number of terms, including the intercept, in the model

:math:`k` - the number of terms, not including the intercept, in the model

:math:`n` - the number of responses used to create the model

:math:`n_v` - the number of responses used to verify the model

:math:`m` - the number of variables

:math:`M` - the model interaction matrix 

Concepts
=========

Orthogonal Polynomials
-----------------------
Each variable has orthogonal polynomials that depend on its distribution. The 
common variables used in UQPCE and their corresponding weighting functions are 
shown in the table below.

+--------------+---------------------------------------------------------------------------------------------+--------------------------+
| distribution | weighting function                                                                          | range                    |
+==============+=============================================================================================+==========================+ 
| normal       | :math:`\frac{1}{\sqrt{2\pi}} e^{\frac{-x^2}{2}}`                                            | [-:math:`\infty, \infty`]|
+--------------+---------------------------------------------------------------------------------------------+--------------------------+
| uniform      | :math:`\frac{1}{2}`                                                                         | [-1, 1]                  |
+--------------+---------------------------------------------------------------------------------------------+--------------------------+
| exponential  | :math:`e^{-x}`                                                                              | [0, :math:`\infty`]      |
+--------------+---------------------------------------------------------------------------------------------+--------------------------+
| beta         | :math:`\frac{\Gamma(\alpha+\beta)}{\Gamma(\alpha)\Gamma(\beta)}x^{\alpha-1}(1-x)^{\beta-1}` | [0, 1]                   |
+--------------+---------------------------------------------------------------------------------------------+--------------------------+
| gamma        | :math:`x^{\alpha} e^{-x}`                                                                   | [0, :math:`\infty`]      |
+--------------+---------------------------------------------------------------------------------------------+--------------------------+

For the ExponentialVariable, GammaVariable, and Variable classes, the 
Gram-Schmidt process is used to find the orthogonal polynomials. The 
NormalVariable, UniformVariable, and BetaVariable classes use recursive 
equations to calculate each distribution's orthogonal polynomials.

The Gram-Schmidt process uses the below equation to solve for the :math:`i^{th}` 
orthogonal polynomial for a distribution with the weighting function, 
:math:`w(x)`, over the variable's support range [a, b].

.. math::
	\psi_{0}(x)=1

.. math::
	\psi_{i}(x) = x^i + \sum_{j=0}^{i-1}\ -\frac{\int_{a}^{b} x^i\ \psi_{j}(x)\ w(x)\ dx}{\int_{a}^{b} \psi_{j}(x)^2\ w(x)\ dx}\ \psi_{j}(x)

|

This leads to the orthogonal polynomials

.. math::
	\psi_{1}(x)=x -\frac{\int_{a}^{b} x\ \psi_{0}(x)\ w(x)\ dx}{\int_{a}^{b} \psi_{0}(x)^2\ w(x)\ dx}\ \psi_{0}(x)

.. math::
	\psi_{2}(x)=x^2 -\frac{\int_{a}^{b} x^2\ \psi_{0}(x)\ w(x)\ dx}{\int_{a}^{b} \psi_{0}(x)^2\ w(x)\ dx}
	\ \psi_{0}(x) -\frac{\int_{a}^{b} x^2\ \psi_{1}(x)\ w(x)\ dx}{\int_{a}^{b} \psi_{1}(x)^2\ w(x)\ dx}\ \psi_{1}(x)

.. math::
	.\ .\ .

|

Since :math:`\psi_{0}(x)=1`, the first orthogonal polynomials become
	
.. math::
	\psi_{1}(x)=x -\frac{\int_{a}^{b} x\ w(x)\ dx}{\int_{a}^{b} w(x)\ dx}

.. math::
	\psi_{2}(x)=x^2 -\frac{\int_{a}^{b} x^2\ w(x)\ dx}{\int_{a}^{b}\ w(x)\ dx}
	\ -\frac{\int_{a}^{b} x^2\ \psi_{1}(x)\ w(x)\ dx}{\int_{a}^{b} \psi_{1}(x)^2\ w(x)\ dx}\ \psi_{1}(x)
	
.. math::
	.\ .\ .

Norm Squared
--------------
The BetaVariable, ExponentialVariable, GammaVariable, and Variable classes use 
the following method to calculate each variable's univariate norm squared. The 
UniformVariable and NormalVariable classes use equations to generate the 
univariate norm squared values.

The univariate norm squared is given by 

.. math::
	\langle\Psi_{i}^{2}\rangle = \int_{a}^{b} w(x) (\psi_{i}(x))^{2} dx

where :math:`a` and :math:`b` are the bounds of the variable's support range, 
function :math:`w(x)` is the weighting function, and :math:`\psi_{i}(x)` is the 
orthogonal polynomial for order :math:`i`.

For example, given that the second order Hermite polynomial is

.. math::
	\psi_{2} = H_{2} = x^{2} - 1

a normal variable where :math:`i` = 2 would have a univariate norm squared of

.. math::
	\langle\Psi_{2}^{2}\rangle = \int_{a}^{b} f(x) (\psi_{2}(x))^{2} dx

.. math::
	\langle\Psi_{2}^{2}\rangle = {\int_{-\infty}^{\infty} 
	\frac{1}{\sqrt{2\pi}} e^{\frac{-x^{2}}{2}} (x^{2}-1)^{2} dx}

|

Once these are calculated for each variable, the norm squared of the multivariate orthogonal 
polynomial can be calculated [Eldred2009]_

.. math::
	\langle{\bf \Psi}^{2}_j\rangle=\prod_{i=1}^{m}\langle\Psi_{M_i^j}^{2}\rangle

where :math:`j` is the index of the model term, :math:`i` represents the 
index of the variable, and :math:`M` is the model interaction matrix.

.. _system_of_equations:

Solving the System of Equations
--------------------------------
A system of equations is created in the format of

.. math::
	y(x) \cong \beta X

This technique is used initially to solve for the :math:`\beta` coefficients, 
and it is later used to solve for the responses that the model generates from 
the :math:`\beta` coefficients and the :math:`X` matrix.


Model Interaction Matrix
-------------------------
The model interaction matrix for two variables with order = 2 is given by

.. math::
	M =		\begin{pmatrix}
			0&0\\
			1&0\\
			0&1\\
			2&0\\
			1&1\\
			0&2\\
			\end{pmatrix}

where the columns represent the variables present and the rows represent 
the combinations of interactions up to order = 2 [Eldred2009]_.

Variable Basis
---------------
The values from the model interaction matrix are used as indices for 
forming the variable basis, :math:`X`, as shown below

.. math::
	X_{0}(\textbf{x}) = \psi_{0}(x_{1}) \psi_{0}(x_{2})
	
	X_{1}(\textbf{x}) = \psi_{1}(x_{1}) \psi_{0}(x_{2})
	
	X_{2}(\textbf{x}) = \psi_{0}(x_{1}) \psi_{1}(x_{2})
	
	X_{3}(\textbf{x}) = \psi_{2}(x_{1}) \psi_{0}(x_{2})
	
	X_{4}(\textbf{x}) = \psi_{1}(x_{1}) \psi_{1}(x_{2})
	
	X_{5}(\textbf{x}) = \psi_{0}(x_{1}) \psi_{2}(x_{2})

The integer :math:`i` in :math:`\psi_{i}` represents the order of each 
variable in each row of the interaction matrix, and :math:`\psi_{i}` is a 
function for the respective variable's orthogonal polynomial basis at the given 
order [Eldred2009]_.


Sobol Sensitivity Indices
--------------------------
The Sobol sensitivity indices that are output by UQPCE allow for users to see 
which input parameters the model is most affected by for the given input space.

The Sobol indices are calculated using the matrix coefficients, :math:`\beta`,
and the norm squared, :math:`\langle\Psi^{2}\rangle`, using the below 
equation for all :math:`i \geq 1`.

.. math::
	S_{i-1} = \frac{\beta_i^2 \langle\bf{\Psi}_{i}^{2}\rangle}{\sum_{j=1}^{p} \beta_j^2 \langle\bf{\Psi}_{j}^{2}\rangle}

Note that there is no Sobol is for the intercept term, :math:`\beta_0`.

|

The total Sobol for each variable, :math:`x_i`, is given by

.. math::
	S_{T_{x_i}} = \frac{\sum_{j=1}^{p} P_{i,j}}{\sum_{k=0}^{m-1} \sum_{j=1}^{p} P_{k,j}}

where 

.. math::

	P_{i,j}= \left\{
	  \begin{array}{lr} 
	      S_{j-1} \ , & M_{j,i} > 0\\
	      0 \ , & M_{j,i} = 0\\
	      \end{array}
	\right.


PRESS Residual
---------------
The PRESS residual is the sum of error for all models created with ``n - 1`` 
results, where ``n`` is the total number of results.

.. math::
	PRESS = \sum_{i=1}^{n} e^2_{(i)} = \sum_{i=1}^{n} [y_{i} - \hat{y}_{(i)}]^2

[Montgomery2013]_

As shown above, the error is calculated from the actual response and the 
predicted response from a model that omits point ``i``. The error in the 
prediction is squared and the sum of all of those ``n`` values is the PRESS 
residual.

Mean
-----
The estimate of the mean of the model is given by

.. math::
	\mu \cong \sum_{i=0}^{p} \beta_i X_i = \beta_0

[Eldred2009]_


Variance
---------
The estimate of the variance of the model is given by

.. math::
	\sigma^{2} = \sum_{i=1}^{p} \beta^{2}_i \langle\bf{\Psi}^{2}_i\rangle

[Eldred2009]_


Mean Error
-----------
The mean error is the average differential between model predicted response and 
observed response. The mean error for a model is calculated with

.. math::
	\varepsilon = \frac{\sum_{i=0}^{n} |\hat{y}_i - y_i|}{n}


Signal-to-Noise Ratio
----------------------
The signal-to-noise ratio estimates the relative magnitude of the model 
variance to the model error. This calculation used the model variance, 
:math:`\sigma^{2}`, and the model mean error, :math:`\varepsilon`.

.. math::
    SNR = \frac{\sigma^{2}}{\varepsilon}


Verification Error
-------------------
The verification error is a similar metric to the mean error but is calculated 
using the model verification responses.

.. math::
    \varepsilon_v = \frac{\sum_{i=0}^{n_v} |\hat{y}_{v_{i}} - y_{v_{i}}|}{n_v}


Sample Generation
==================
The techniques used to generate the samples when the ``--generate-samples`` flag 
is used are discussed below.

Inverse Transform Sampling
---------------------------
For the UniformVariable, NormalVariable, BetaVariable, ExponentialVariable, 
and GammaVariable classes, the samples are generated using the respective 
distribution, :math:`f`, for :math:`N` number of samples.

:math:`N` random, uniformly distributed, well-spaced samples on interval 
[0, 1] are generated. These samples are input into the distribution's 
cumulative density function, :math:`CDF`, to acquire samples according to 
distribution :math:`f` that are random and well-spaced.

.. math::
    x = uniform([0, 1], N)

.. math::
	samples = f.CDF(x)

.. _samp_dist:
.. figure:: _images/sample_dist.png
	:scale: 8 %
	:alt: An exponential sample distribution
	:align: center

:numref:`samp_dist` An exponential distribution with vertical black dashed lines 
at 10% intervals of the :math:`CDF`. The green dots show the sample randomly 
generated on each interval.

Generating the samples according to the above figure ensures that the samples 
are random and well-spaced.

The ``Variable`` class uses this method when the :math:`CDF` can be solved for. 
When this fails, the acceptance-rejection sampling method is used.

Acceptance-Rejection Sampling
------------------------------
This method generates:

* An :math:`x` value over the variable's support range
* The corresponding :math:`f(x)`
* A :math:`y` value over range [0, :math:`max(f(x))`]

If :math:`y \leq f(x)`, the :math:`x` value is accepted. If :math:`y > f(x)`, 
the value is rejected. This process is repeated until all :math:`N` samples 
have been generated.

.. _rej_samp:
.. figure:: _images/rej_acc_samp.png
	:scale: 12 %
	:alt: An exponential sample distribution
	:align: center

:numref:`rej_samp` An exponential distribution with green upper triangles as 
the accepted points and the red upside down triangles as the rejected points.

The acceptance-rejection sampling method is often computationally expensive 
due to the large number of samples that are rejected, and the samples aren't 
as well-spaced as the inverse transform sampling method.

