
References
+++++++++++
				
				
.. [Eldred2009] 	M. S. Eldred, "Recent Advances in Non-Intrusive Polynomial 
					Chaos and Stochastic Collocation Methods for Uncertainty 
					Analysis and Design", *Proceedings of the 50th 
					AIAA/ASME/ASCE/AHS/ASC Structures, Structural Dynamics, and 
					Materials Conference*, No. AIAA-2009-2274, Palm Springs, 
					California, May 04-07, 2009.

.. [Montgomery2013] D. C. Montgomery, "Design and Analysis of Experiments", 
					8th. *Wiley*. 2013.