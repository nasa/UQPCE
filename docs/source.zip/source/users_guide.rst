
User's Guide
++++++++++++++++

Introduction
=============

Purpose
---------

Uncertainty Quantification using Polynomial Chaos Expansion (UQPCE) is an open 
source, python based research code for use in parametric, non-deterministic 
computational studies. UQPCE utilizes a non-intrusive polynomial chaos 
expansion surrogate modeling technique to efficiently estimate uncertainties 
for computational analyses. The software allows the user to perform an 
automated uncertainty analysis for any given computational code without 
requiring modification to the source. UQPCE estimates sensitivities, 
confidence intervals, and other model statistics, which can be useful in the 
conceptual design and analysis of flight vehicles. This software was developed 
for the Aeronautics Systems Analysis Branch (`ASAB`_) within the Systems 
Analysis and Concepts Directorate (`SACD`_) at `NASA Langley Research Center`__ 
to study potential impacts of uncertainties on the prediction of ground noise 
generated from commercial supersonic aircraft concepts.


.. _NASA: https://www.nasa.gov/langley

__ NASA_

.. _ASAB: https://sacd.larc.nasa.gov/asab/

.. _SACD: https://sacd.larc.nasa.gov/
   
   
Installation
================
The prerequisites, setup, and execution will be covered in this section.

Prerequisites
----------------

`Python`_ 3.6 or higher is required for running the program.

Below shows the packages required for using this program, their 
minimum versions, and installation instructions.

`Matplotlib`_ : *2.1.0*
::

	pip install --user matplotlib

`NumPy`_ : *1.13.3*
::

	pip install --user numpy

`PyYAML`_ : *3.13*
::

	pip install pyyaml

`SciPy`_ : *1.1.0*
::

	pip install --user scipy

`SymPy`_ : *1.4*
::

	pip install --user sympy

Environment
------------
Included in this distribution is an ``environment.yml`` file in the ``env`` 
folder. Follow the instructions on the `conda`_ website to build an environment 
from this file.


Program Organization
---------------------

The code is located in ``UQPCE/src/PCE_Codes``. Below are the names of the files 
required for the program to run properly.

	- __main__.py
	
	- UQPCE.py
	

Renaming these files and folders is not advised. If the names of the python files 
change, the program will likely stop working. If the inner folder ``PCE_Codes`` 
is renamed, the program will not work as expected.


Running the Program
----------------------
UQPCE can be run on both Linux and Windows systems, and instructions on 
how to successful run UQPCE on both operating systems will be discussed below.

.. 
	Grayskull (LaRC)
	~~~~~~~~~~~~~~~~
		#. In folder ``/home/sacd/user_name``, type 
		   ``source ../applications/UQ/UQPCE/UQPCE_activate``. If 
		   this outputs an error, type 
		   ``source ../applications/UQ/UQPCE/UQPCE_activate.csh``. If 
		   done correctly, the environment name should show up in brackets as shown 
		   below::
		
				[UQPCE_env] [user_name@grayskull UQPCE]$
		   
		#. Ensure there is at minimum:
			- a yaml file containing the input variables and their information
			- a file containing the results from the program whose system will be 
			  analyzed
			- a file containing the matrix of the values for each input variable
	
		#. Type ``python -m PCE_Codes {additional arguments}`` to run the 
		   program.
	
		If this is done correctly, the command line  might look like::
	
			source ../applications/UQ/UQPCE/UQPCE_activate.csh
			python -m PCE_Codes -o 3
	
		When finished using UQPCE, type ``deactivate`` to exit the virtual 
		environment.
	
		.. note::
		
			UQPCE_env can be activated from any folder as long as the relative path 
			between the two locations is correct. Once the UQPCE_env has been activated, 
			the code can be run from any folder. UQPCE will look for the files in 
			the location the user is in when the code is run.

Linux
~~~~~~~
	#. Set the ``PATH`` and ``PYTHONPATH`` up to the directory that contains
	   ``PCE_Codes``. These commands for setting the environment `variables`_ 
	   differ with the type of shell used.
	   
	#. Ensure there is at minimum:
		- a yaml file containing the input variables and their information
		- a file containing the results from the program whose system will be 
		  analyzed
		- a file containing the matrix of the values for each input variable
			
	#. Type ``python -m PCE_Codes {additional arguments}`` to run the 
	   program.
	
	If this is done correctly, the command line  might look like::
	
		setenv PATH "$PATH:{path}/UQPCE/src"
		set PYTHONPATH={path}/UQPCE/src
		python -m PCE_Codes
		
		
	.. note::
	
		If MatPlotLib is giving an error, the backend may need to be 
		changed to a backend that is compatible with the system.

		The available MatPlotLib backends and their descriptions are given in 
		the `MatPlotLib documentation`__.

		When running the program, use the option ``-b {backend name}``.
	
	
Windows
~~~~~~~~
	It is recommended to run the program in Linux due to the ease of doing so. 
	However, if the user desires to use Windows and an IDE, this is also 
	possible.
	
	Below are the instructions for using Eclipse with PyDev for running the 
	project. Any IDE can be used with this software, but the setup on other 
	IDEs may vary.
	
	#. Ensure that Eclipse has PyDev configured, and create a project. In the 
	   below instructions, replace "ProjectName" with the project name.
	
	#. Follow ``Run As`` > ``Run Configurations`` > 
	   ``Python Run`` > ``ProjectName __main__.py`` and add the ``src`` 
	   directory to the PYTHONPATH. 
	
	#. Next, go to the ``Arguments`` tab and change the working directory to go 
	   to the ``src`` directory.
	
		This might look something like::
	
			${workspace_loc:ProjectName/UQPCE/src}
	
	#. From here, go to ``Program arguments``. This is where command line 
	   options and flags can be added (see the command line `arguments`_).

	#. Go to ``Window`` > ``Preferences`` > ``PyDev`` > ``Run``. Check the 
	   box next to ``Launch modules with "python -m mod.name" instead of 
	   "python filename.py"?``

	#. Go to ``Run As`` > ``ProjectName __main__.py``

	If these steps were followed correctly, the program should run.
	
.. note::
	If the error ``ImportError: cannot import name 'Enum' from 'enum'`` is raised,
	the PYTHONPATH is likely incorrect. See the above instructions and ensure 
	that it is consistent with the above PYTHONPATH.
	
Options
########
#. Specific MatPlotLib backend
	Go to ``Run As`` > ``Run Configurations`` > ``Python Run`` > 
	``ProjectName __main__.py`` > ``Environment``. From here, add a variable 
	MPLBACKEND and set it to the preferred backend.

#. Debug
	Set environment variable ``PYDEVD_USE_CYTHON = NO`` in the same 
	``Environment`` tab.

#. Code Folding
	Go to ``Window > Preferences > PyDev > Editor > Code Folding``.
	Check the boxes ``Use Code Folding?`` and ``Fold #region/#endregion?``.
	
.. _Python: https://www.python.org/
.. _NumPy: https://docs.scipy.org/doc/numpy/reference/
.. _PyYAML: https://pyyaml.org/
.. _SymPy: https://www.sympy.org/en/index.html
.. _SciPy: https://www.scipy.org/
.. _Matplotlib: https://matplotlib.org/

.. _MatPlotLib_Docs: https://matplotlib.org/3.1.0/api/index_backend_api.html
__ MatPlotLib_Docs_


Appendix
=========
This section will cover input files, command line options, and the UQPCE outputs.

Input Files
------------
The required and optional files that UQPCE uses will be discussed below.

Required
~~~~~~~~~~
#. Variable File
		
	*default* : ``input.yaml``
	
	Below is an example of an entry in the variable input file::
	
		Variable 0:
		  name: Mach
		  distribution: normal
		  mean: 2      
		  stdev: 0.02
		  typo: aleatory     # if there is an attribute that doesn't belong to the variable, 
		  type: epistemic    # UQPCE will raise a warning
		Variable 1:    # this name doesn't actually get used; call it something helpful
		  distribution: uniform
		  interval_low: 0
		  interval_high: 5000
		  type: aleatory
		Variable 2:      
		  distribution: 1/sqrt(2*pi*(0.1)**2) * exp(-(x-1)**2/(2*(0.1)**2))
		  interval_low: -oo
		  interval_high: oo  # indenting with spaces is fine, but
		  type: aleatory     # if we use a tab character (\t), we have problems
		Variable 4: { distribution: sin(x), interval_low: 0, interval_high: pi, type: aleatory } # this is a valid YAML form
		  
		Settings:    # Settings can also be in the yaml form "Variable 4" is in
		  order: 3
		  significance: 0.05
		  verbose: true
		  version: true
		  plot: true
		  
	
	|

	Below are the variable inputs and their supported values if applicable:
	
	The **bold** represents the attribute name, the ``literal`` represents 
	the accepted type(s) of the attribute, and the *italics* represents if 
	an attribute is optional or required.

	**type** : ``Enum`` : *required*
	
			This option is the uncertainty type that the variable is.
		
				**aleatory**
			
				**epistemic**
			
			
	**distribution** : ``Enum`` -or- ``str`` : *required*
	
			This option is the distribution that the variable data follows. The 
			allowed ``Enum`` types are shown below.
		
				**normal**
				
				**uniform**
	
				**beta**
	
				**exponential**
				
				**gamma**
			
			Alternatively, an equation that is written in accordance with SymPy_ 
			syntax can be input.
			
				Example:
				
					sqrt(2 * pi)  =  :math:`\sqrt{2\pi}`
				
					exp(-x)  =  :math:`e^{-x}`
						
			Both of these options can be used for a variable. Users must be 
			careful when using the equation based :ref:`variable`.

	**mean** : ``float`` : *required*\*\*
			
			This option is the mean of the data.
	
	**stdev** : ``float`` : *required*\*\*
	
			This option is the standard deviation of the data.
	
	**interval_low** : ``float`` : *required*\*\*
	
			This option is the lower interval on which the data lies.
	
	**interval_high** : ``float`` : *required*\*\*
	
			This option is the upper interval on which the data lies.
		
	**alpha** : ``float`` : *required*\*\*
		
			The :math:`\alpha` parameter of the BetaVariable and the GammaVariable.
			
	**beta** : ``float`` : *required*\*\*

			The :math:`\beta` parameter of the BetaVariable.

	**theta** : ``float`` : *required*\*\*
			
			The :math:`\theta` parameter of the GammaVariable.

	**lambda** : ``float`` : *required*\*\*
			
			The :math:`\lambda` parameter of the ExponentialVariable.

	**name** : ``str`` : *default* = ``x{number}`` : *optional*
	
			This option is the name for the physical meaning of the 
			variable. 

	|
	
	\*\* The ``normal`` distribution requires **mean** and **stdev** in addition to 
	the attributes all variables require.
	
	\*\* The ``uniform`` distribution requires **interval_low** and **interval_high** 
	in addition to the attributes all variables require.
	
	\*\* The ``beta`` distribution requires **alpha** and **beta** in addition to 
	the attributes all variables require. It has additional optional values 
	**interval_low** (default = ``0``) and **interval_high** (default = ``1``).
	
	\*\* The ``exponential`` distribution requires **lambda** in addition to 
	the attributes all variables require. It has optional value **interval_low** 
	(default = ``0``).
	
	\*\* The ``gamma`` distribution requires **alpha** and **theta** in addition to 
	the attributes all variables require. It has additional optional value 
	**interval_low** (default = ``0``).
		
	\*\* The ``user input`` distribution requires **interval_low** and 
	**interval_high** in addition to the attributes all variables require.
		
	|

	Refer to the `Variables <background.html#variables>`__ section for more 
	information on the distributions.
	
	|
	
	Below are some key things to keep in mind for the YAML file:
	
	* The variable inputs that are of type ``Enum`` allow for any 
	  capitalization of the input. 
	
	* All of the values that take a float value can also take ``pi`` as 
	  the input value.
	  
	* The general ``Variable`` inputs ``interval_low`` and ``interval_high`` 
	  can take ``-oo`` *(-infinity)* and ``oo`` *(infinity)*, respectively.
	
	* Command line arguments can be put in the input file in the "Settings" 
	  section::
		
		as a flag		--track-convergence-off
		in a file		track_convergence_off: true
	
	  * When using the file to set the program options, use the long version 
	    of the flag names. Using ``b`` will not work; ``backend`` must be used. 
	
	  * When using a flag option in the input file, these options must be set 
	    equal to ``true``. The YAML conventions of Booleans apply.
	
	* When adding comments to the YAML file, comments need to begin with a new 
	  line a new line and start with ``"#"``. Comments that are in-line with an 
	  input should begin with ``" #"`` (space before the ``#``).
	
	|
	
	The organization of the YAML file shown in this example is not the only 
	valid way to organize it. See `PyYAML`_ for more information.

	.. note::
		YAML files are sensitive to spacing and tabs. Ensure that there are no 
		trailing spaces in the lines. See the `PyYAML Documentation`__ 
		for more information. 


#. Matrix File

	This data file must be organized such that each column contains the 
	values for one variable and each row contains all of the input values for 
	one run of the program UQPCE is modeling. The columns should be separated 
	by space.
	
	*default* : ``run_matrix.dat``
	
	.. image:: _images/run_matrix.png
		:height: 200px
		:width: 1000px
		:scale: 100%
		:alt: A diagram depicting the setup of the run matrix file
		:align: center

	Above is an example of the setup of the matrix file and how it corresponds 
	to each variable and set of inputs for the program that will be modeled.
	
#. Results File

	This file should be organized such that each row contains the result 
	corresponding to one row of the run matrix. If desired, there can be 
	more than one column in this file, which also must correspond to one 
	row of the matrix file.
	
	*default* : ``results.dat``
	
	An example is shown below::
	
		Propulsion_1st			Propulsion_2nd
		44.755				45.675
		43.592				56.642
		51.861				48.914
		50.416				42.973
		42.235				52.368
		58.457				50.433
	
	If there are multiple columns in this file, it can be helpful to add a 
	name. The name will proceed the usual file and folder names so that the 
	outputs are clear. If no name is given and there are multiple rows, 
	default names of ``results_column_{number}`` are given.
		
Optional
~~~~~~~~~

#. Verification Matrix

	*default* : ``verification_run_matrix.dat``
	
	This file is set up like the matrix file. This file will only be used 
	if the ``--verify`` flag is used.


#. Verification Results

	*default* : ``verification_results.dat``
	
	This file is set up like the results file. This file will only be used 
	if the ``--verify`` flag is used.
		
.. note::
	Using verification runs for model validation is highly encouraged and 
	should be considered a best practice in implementing this code.

.. _arguments:

Command Line Arguments
-------------------------

Options
~~~~~~~~~~
::

	-h, --help				show help message and exit
	-i, --input-file			file containing variables (default: input.yaml)
	-m, --matrix-file			file containing matrix elements (default: 
						run_matrix.dat)
	-r, --results-file			file containing results (default: results.dat)
	--verification-matrix-file		file containing verification matrix elements 
						(default: verification_run_matrix.dat)
	--verification-results-file		file containing verification results 
						(default: verification_results.dat)
	--output-directory			directory that the outputs will be put in 
						(default: outputs)
	-c, --case				case of input data (default: None)
	-s, --significance			significance level of the confidence interval 
						(default: 0.05)
	-o, --order				order of PCE expansion (default: 2)
	-f, --user-func				allows the user to specify the analytical 
                        			function for the data (default: None)
	--over-samp-ratio			over sampling ratio; factor for how many points 
                        			to be used in calculations (default: 2)
	-b, -backend				the backend that will be used for Matplotlib 
						plotting (default: TkAgg)
	--conv-threshold-percent		the decimal percent of the response mean to be 
                        			used as a threshold for tracking convergence 
                        			(default: 0.0005)
	--epist-samp-size			the number of times to sample for each variable 
                        			with epistemic uncertainty (default: 125)
	--aleat-samp-size			the number of times to sample for each varaible 
                        			with aleatory uncertainty (default: 25000)
	--epist-sub-samp-size			the number of curves to check the new high 
                        			and low intervals at for a set of curves 
                        			(default: 25)
	--aleat-sub-samp-size			the number of samples to check the new high 
                        			and low intervals at for each individual 
                        			curve (default: 5000)

................................................................................

Example:

	``python -m PCE_Codes --option arg``
	
	``python -m PCE_Codes -o arg``
	

................................................................................


Flags
~~~~~~~~
::

	-v, --version			displays the version of the software
	--verbose			increase output verbosity
	--verify			allows verification of results
	--plot				generates factor vs response plots, pbox plot, and error 
					plots
	--plot-stand			plots standardized variables
	--track-convergence-off		allows users to converge on confidence interval 
                        		until the change between the two iterations is 
                        		less than the threshold
	--generate-samples		generates the samples used for all variables 
                        		according to the parameters provided in the input 
                        		file

................................................................................

Example:

	``python -m PCE_Codes --flag``
	
	``python -m PCE_Codes -f``

................................................................................


Outputs
---------

Output Files
~~~~~~~~~~~~~

There are four output files generated in addition to the probability box plot, 
error distribution plots, and the optional graphs.

#. output_{case_name}.dat
	This file contains information about the individual run as well as 
	the mean, variance, and confidence interval of the responses.
	
	An example output is shown below::
	
		###          UQPCE v0.2.0 Output          
		###  Analysis started: 2019-07-15 13:11:40.659411               
		###  Analysis finished: 2019-07-15 13:12:08.670735               
		###  Total compute time: 0:00:28.011324               
		------------------------------------------------------------------------
		Mean of response 43.81181
		Variance of response 84.21911
		Mean error of surrogate 0.04036
		Signal to noise ratio 2086.80741
		95.0% Confidence Interval on Response [28.010, 64.057]
		
		Shapiro-Wilks test statistic is 0.98042, P-value is 0.83665
	
		Insufficient evidence to infer errors are not from a normal distribution
		

		
		The settings used to generate these results are:
		
		input_file: input.yaml
		matrix_file: run_matrix.dat
		results_file: results.dat
		verification_results_file: verification_results.dat
		verification_matrix_file: verification_run_matrix.dat
		case: None
		significance: 0.05
		order: 2
		user_func: None
		over_samp_ratio: 3.0
		backend: TkAgg
		aleat_sub_samp_size: 5000
		epist_sub_samp_size: 25
		conv_threshold_percent: 0.0005
		epist_samp_size: 125
		aleat_samp_size: 25000
		verbose: True
		version: False
		verify: False
		plot: True
		plot_stand: True
		track_convergence_off: False
		generate_samples: False
		
		

			
		The input file used is:
		
		Variable 0:
		  distribution: normal
		  mean: 1
		  stdev: 0.1
		  type: aleatory
		Variable 1:
		  distribution: normal
		  mean: 2
		  stdev: 0.2
		  type: aleatory
		Variable 2:
		  distribution: normal
		  mean: 3
		  stdev: 0.3
		  type: aleatory
		  
		Settings:
		  order: 2
		  verbose: true
		  plot: true
		  plot_stand: true
	
	Labeled information about the case, data, and model are displayed.

#. sobol_{case_name}.dat
	This file contains the Sobol indices for the model parameters. These 
	indices represent how sensitive the model is to each parameter. These 
	values will always sum together to equal one.
	
	An example output is shown below::
	
		x0                                          0.00018
		x1                                          0.94983
		x0^2                                        0.00000
		x0*x1                                       0.00000
		x1^2                                        0.04999
		
		
		total Sobol x0 = 0.04778
		total Sobol x1 = 0.95222
	
	The interaction that the Sobol index represents is listed beside each 
	value for clarity. x0 is the first variable in the input file, x1 is the 
	second, and so on.
	
#. coefficients_{case_name}.dat
	This file contains the intercept of the responses as well as the 
	coefficients from solving the system of equations. These coefficients 
	show how much the responses change based on each of the combinations 
	of input parameters.
	
	An example output is shown below::
	
		intercept                                   43.8118
		x0                                          0.22363
		x1                                          0.00023
		x0^2                                        0.00893
		x0*x1                                       0.00000
		x1^2                                        9.75792
		
	From this output, we have the intercept of the data and the coefficients 
	for the interaction terms in the matrix system.

#. convergence_values.dat
	This file is located in the graph directory, and it is created when tracking 
	convergence is left on. For each set of epistemic sample iterations, all of 
	the low and high confidence intervals are generated, and the overall low 
	and high intervals for the set are displayed. This allows the user to view 
	the convergence for both the set of curves.
	
	An example of this file with no epistemic variables is shown below::
	
		low:  [87.9223907053667, 87.96646060205886, 88.01792539580406, 87.83992456472066, 87.80174323289735]
		high: [128.7802929016811, 128.72131677630222, 128.56207338904005, 128.6577881178519, 128.56207338904005]
		  
	Each set of ``low`` and ``high`` values corresponds to an individual curve 
	as it increases in sample number.
		    

	In the case of one or more epistemic variables, the file will contain the 
	values of the overall confidence interval for sets of curves as they converge::
	
		set: [46.835342059289935, 51.323999003168474]
		set: [46.799205926776334, 51.423733890432326]
		    
	The set of values ``set`` represents one set of curves and its lowest limits 
	of the confidence interval.   


Graphs
~~~~~~~~

Graphs that represent the distribution of the error will be generated each time 
the program is run.

	The error distribution plot (*error_distribution.png*) is a histogram of 
	the error values between the model-predicted responses and the responses 
	from the file. This allows users to visualize the magnitude and 
	distribution of the error. Ideally, this should follow a normal 
	distribution.

	The normal probability plot (*normal_prob.png*) shows how well the error 
	values fit to a normal distribution. The actual error values are plotted 
	against a theoretical normal distribution. If the error follows a normal 
	distribution, the plot will follow the linear best fit line.
	
	The low and high convergence values for the individual curves are plotted 
	in *CIL_convergence.png* and *CIH_convergence.png*, respectively. Each line 
	represents one curve and how it converges over many iterations.


If the ``--plot`` flag is used, additional graphs will be created. Looking at 
these graphs will help the user determine if the surrogate model accurately 
represents the underlying data.
	
	For example, the error versus variable graphs will plot the error of the 
	model at each point with the corresponding value of each variable. If there 
	is a trend between the error and the value of the variable, this suggests 
	that the model may not be accurately capturing that variables behavior 
	within the uncertainty space.
	
	The predicted values versus variable graphs show to correlation between the 
	variable input values and the predicted response values. The graphs help 
	users visualize the correlation between these and how strongly the model 
	relies on each of these input variables.
	
	
.. _tests:

Tests
======
The following section will cover how to execute the tests included in the UQPCE 
package.


Verification Cases
-------------------

To run all verification cases, unzip the verification case folders, add 
``PCE_Codes`` to the ``PATH`` and ``PYTHONPATH``, and run the below command.

::

	python check_verification_cases.py
	
This will run all  of the verification cases and collect a file of their means 
and variances so the user can test that UQPCE is working appropriately.


Unittest
----------

The unittest will run tests for all of the functions and methods used in UQPCE. To 
execute the unittest, add ``PCE_Codes`` to the ``PATH`` and ``PYTHONPATH`` and 
run the below command.

::

	python -m test_uqpce


.. _PyYAML_Docs: https://pyyaml.org/wiki/PyYAMLDocumentation

.. _variables: https://matplotlib.org/3.1.1/faq/environment_variables_faq.html

.. _conda: https://docs.conda.io/projects/conda/en/latest/user-guide/tasks/manage-environments.html

__ PyYAML_Docs_
