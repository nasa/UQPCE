.. _verification-cases:

Verification Cases
+++++++++++++++++++

With the data files included, the user can run UQPCE using the input case
files and compare the mean, variance, and confidence intervals with those of 
the values in the ``MC`` files acquired from using a Monte-Carlo Simulation 
approach.

These examples are included to demonstrate the use of UQPCE for varying 
problems. To run the verification cases, the user's current working directory 
must be one of the folders for the verification cases.

You can run a case using the commands::

	set PYTHONPATH={path to folder}/PCE_Codes/src
	python -m PCE_Codes 
	
Additionally, consider using 
	- ``--verbose`` to make the program output its current steps
	- ``-o 3`` to have a 3rd order polynomial chaos expansion
	- ``-c NACA0012`` to name the files appropriately
	- ``--epist-samp-size 200`` to increase the number of curves created for 
	  calculating the confidence interval
	- ``--conv-threshold-percent 0.0005`` to make the resampling stop once the 
	  confidence intervals have not changed more than 0.05% between iterations
	- ``--plot`` to generate the probability box plot and error versus variable 
	  plots
	- ``--verify`` to use verification points and see how much error there is 
	  between the model and actual points that weren't used to create the model

	.. note::
	
		More variables, the presence of epistemic variables, and a higher order 
		increases the time required by UQPCE.

To run all of the verification cases together, see :ref:`tests`.


Transonic NACA0012 Airfoil
============================

#. Background

	The lift coefficient (CL) and drag coefficient (CD) of a NACA 0012 airfoil 
	are studied in the case of transonic flight running an RANS CFD code. The 
	inputs for the simulation are the Mach number, angle of attack (alpha), 
	altitude, von Karman constant (vonKarman), and sigma.

	Follow the instructions above, using whichever flags and options you are 
	interested in. For this example, unzip the folder ``naca_0012.zip`` and use 
	``naca_0012`` as {folder name}.

#. Outputs

	When you execute the module, you should get results similar to those below.
	
	**Lift Coefficient**
	
	+---------------------+--------------------+--------------------+
	|                     | UQPCE              | Monte-Carlo        |
	+=====================+====================+====================+ 
	| mean                | 0.21875            | 0.21875            |
	+---------------------+--------------------+--------------------+
	| variance            | 1.425e-4           | 1.420e-4           |
	+---------------------+--------------------+--------------------+
	| confidence interval | [0.1843, 0.2484]   | [0.1950, 0.2412]   |
	+---------------------+--------------------+--------------------+
	
	**Drag Coefficient**
	
	+---------------------+----------------------+----------------------+
	|                     | UQPCE                | Monte-Carlo          |
	+=====================+======================+======================+ 
	| mean                | 0.028205             | 0.028204             |
	+---------------------+----------------------+----------------------+
	| variance            | 1.236e-06            | 1.231e-06            |
	+---------------------+----------------------+----------------------+
	| confidence interval | [0.0253, 0.0313]     | [0.0261, 0.0304]     |
	+---------------------+----------------------+----------------------+
	
	.. _naca0012_lc_pbox:
	.. figure:: _images/p-box.png
		:scale: 8 %
		:alt: The lift coefficient probability box
		:align: center
	
	:numref:`naca0012_lc_pbox` The 95% confidence interval of the lift 
	coefficient is found by interpolating to find the values that belong at 
	2.5% and 97.5% of the responses.
	
	.. _CIL_conv:
	.. figure:: _images/CIL_convergence.png
		:scale: 8 %
		:alt: The convergence of the lower intervals of the lift coefficient
		:align: center
		
	:numref:`CIL_conv`. The lower confidence intervals of the lift 
	coefficient for each curve converging with additional evaluations.
	
	.. _CIH_conv:
	.. figure:: _images/CIH_convergence.png
		:scale: 8 %
		:alt: The convergence of the upper intervals of the lift coefficient
		:align: center
		
	:numref:`CIH_conv`. The upper confidence intervals of the lift 
	coefficient for each curve converging with additional evaluations.
	
	Along with these convergence plots of the individual curves, the sets of 
	curves have their overall convergence intervals written to a file.
	
	The corresponding output of this file for the lift coefficient is shown 
	below::
	
		    set: [0.18745724466451097, 0.24735395659860618]
		    set: [0.18607906409253214, 0.2475065011187474]
		    set: [0.18607906409253214, 0.2475065011187474]
		    set: [0.18607906409253214, 0.24759772917464634]


	If the ``--verify`` flag is used with the included files, the 
	user should get an output similar to the following for the lift 
	coefficient::
		
		Mean error between model and verification 3.146e-05

	The user should get an output similar to the following for the lift 
	coefficient::
	
		Mean error between model and verification 1.3294e-06
		
	Since these are much smaller than the means and confidence intervals, this 
	suggests that the model is a good fit for this set of data.



Supersonic Diamond Airfoil
===========================

#. Background

	The ground noise, obtained from the off-body pressure signature, is the 
	response of interest in the case of the diamond airfoil. The inputs are the 
	Mach number, the angle of attack (AoA), ground altitude, reflection factor 
	(RF), x-velocity of wind, y-velocity of wind, relative humidity (hum), and 
	temperature.

	Follow the instructions above, using whichever flags and options you are 
	interested in. For this example, unzip the folder ``diamond_airfoil.zip`` 
	and execute ``PCE_Codes`` from the ``diamond_airfoil`` directory.
	
#. Outputs
	
	When you run these files, you should get similar results to those below.
	
		**dBA**
		
		+---------------------+---------------------------+----------------------+
		|                     | UQPCE                     | Monte-Carlo          |
		+=====================+===========================+======================+ 
		| mean                | 100.9                     | 100.87               |
		+---------------------+---------------------------+----------------------+
		| variance            | 0.098999                  | 0.090497             |
		+---------------------+---------------------------+----------------------+
		| confidence interval | [100.13, 101.72]          | [100.31, 101.46]     |
		+---------------------+---------------------------+----------------------+
		
	The above chart shows the UQPCE versus Monte-Carlo mean, variance, and 
	confidence intervals for the A-weighted decibels (dBA).
	
	If the ``--verify`` flag is used with the included files, the 
	user should get an output similar to the following for the lift 
	coefficient::

		Mean error between model and verification 0.0086068
		
	Since this value is to the same order of magnitude as the mean error of the 
	surrogate, ``0.0061665`` and the signal to noise ratio is ``16.054``, this 
	model is a reasonable approximation for the system.
	
		
		**dBC**
		
		+---------------------+---------------------------+----------------------+
		|                     | UQPCE                     | Monte-Carlo          |
		+=====================+===========================+======================+ 
		| mean                | 116.5                     | 116.48               |
		+---------------------+---------------------------+----------------------+
		| variance            | 0.0781                    | 0.0718               |
		+---------------------+---------------------------+----------------------+
		| confidence interval | [115.92, 117.12]          | [116.01, 116.97]     |
		+---------------------+---------------------------+----------------------+
	
	The above chart shows the UQPCE versus Monte-Carlo mean, variance, and 
	confidence intervals for the C-weighted decibels (dBC).
	
	If the ``--verify`` flag is used with the included files, the 
	user should get an output similar to the following for the lift 
	coefficient::
	
		Mean error between model and verification 0.0016291
	
	Since this value is to the same order of magnitude as the surrogate, 
	``0.0010945`` and the signal to noise ratio is ``71.336``, this is a 
	reasonable approximation for the system.
	
	
		**PLdB**
		
		+---------------------+---------------------------+----------------------+
		|                     | UQPCE                     | Monte-Carlo          |
		+=====================+===========================+======================+ 
		| mean                | 116.29                    | 116.26               |
		+---------------------+---------------------------+----------------------+
		| variance            | 0.1224                    | 0.1124               |
		+---------------------+---------------------------+----------------------+
		| confidence interval | [115.53, 117.17]          | [115.46, 117.1]      |
		+---------------------+---------------------------+----------------------+
	
	The above chart shows the UQPCE versus Monte-Carlo mean, variance, and 
	confidence intervals for the perceived loudness (PLdB).
	
	If the ``--verify`` flag is used with the included files, the 
	user should get an output similar to the following for the lift 
	coefficient::
	
		Mean error between model and verification 0.012474
	
	Since this value is close to the mean error of the surrogate, ``0.0079942``, 
	and the signal to noise ratio is ``15.308``, this is a reasonable 
	approximation for the system.


OneraM6 Airfoil
================

#. Background

	The lift coefficient (CL) and drag coefficient (CD) OneraM6 airfoil are 
	studied. The inputs for the simulation are the Mach number and angle of 
	attack.
	
	Follow the instructions above, using whichever flags and options you are 
	interested in. For this example, unzip the folder ``onera_m6.zip`` and 
	execute ``PCE_Codes`` from the ``onera_m6`` directory.
	
#. Outputs
	
	When you run these files, you should get results similar to those below.
	
	**Lift Coefficient**
	
	+---------------------+------------------------+------------------------+
	|                     | UQPCE                  | Monte-Carlo            |
	+=====================+========================+========================+ 
	| mean                | 0.29296                | 0.29288                |
	+---------------------+------------------------+------------------------+
	| variance            | 2.713e-4               | 2.739e-4               |
	+---------------------+------------------------+------------------------+
	| confidence interval | [0.26163, 0.3262]      | [0.2611, 0.3259]       |
	+---------------------+------------------------+------------------------+
	
	This case was run with ``order = 2``, which is the lowest order that gives 
	us reliable results in this case.

	If the ``--verify`` flag is used, you will see output similar to below::
	
		Mean error between model and verification 7.3086e-05
		
	Which is of the same order of magnitude of the mean error of the surrogate, 
	``2.8925e-05``. This suggests that the model is fitting the data well.
	
	**Drag Coefficient**
	
	+---------------------+----------------------+----------------------+
	|                     | UQPCE                | Monte-Carlo          |
	+=====================+======================+======================+ 
	| mean                | 0.01767              | 0.01766              |
	+---------------------+----------------------+----------------------+
	| variance            | 3.660e-06            | 3.686e-06            |
	+---------------------+----------------------+----------------------+
	| confidence interval | [0.0145, 0.0219]     | [0.0144, 0.0219]     |
	+---------------------+----------------------+----------------------+

	This case was run with ``order = 3``, which is the lowest order that gives 
	us reliable results in this case.

	If the ``--verify`` flag is used, you will see output similar to below::
	
		Mean error between model and verification 1.1883e-05
		
	Which is only one order of magnitude of the mean error of the surrogate, 
	``2.8941e-06``. Since the signal to noise ratio is ``1.2646``, this 
	suggests that the model is fitting the data reasonably well.
	
	The below plots are created using the ``--plot`` and ``--plot-stand`` 
	flags. They represent the outputs for the drag coefficient case with 
	``order = 3``.
	
	.. _onera_m6_CD_pbox:
	.. figure:: _images/onera_m6_CD_pbox.png
		:scale: 8%
		:alt: The probability box for the lift coefficient for the Onera M6
		:align: center
		
	:numref:`onera_m6_CD_pbox`. The lift coefficient probability box for the 
	OneraM6 airfoil.
	
	.. _onera_m6_CIL:
	.. figure:: _images/onera_m6_CIL_convergence.png
		:scale: 8%
		:alt: The convergence of the lower confidence interval for the Onera M6
		:align: center
		
	:numref:`onera_m6_CIL`. The convergence of the lower confidence 
	interval for the OneraM6 airfoil.
	
	.. _onera_m6_CIH:
	.. figure:: _images/onera_m6_CIH_convergence.png
		:scale: 8%
		:alt: The convergence of the upper confidence interval for the Onera M6
		:align: center
		
	:numref:`onera_m6_CIH`. The convergence of the upper confidence 
	interval for the OneraM6 airfoil.
	
	The file containing the convergence values looks like the following::
	
		low:  [0.014457565322569664, 0.014457565322569664, 0.01445999863254389, 0.014449842360062486]
		high: [0.021977720803637357, 0.02195451100712743, 0.021967892240129253, 0.021967892240129253]
		
	The above figures show the probability box plot and the lower and 
	upper confidence interval convergence for the OneraM6 airfoil case. Since 
	none of the variables are epistemic, there is only one curve for the probability box.
	As shown, these confidence intervals did not converge within the accepted 
	threshold and instead used the maximum number of samples allowed. It is 
	possible for the curves to converge and not appear to be converged as 
	long as the last two differences between confidence intervals are within 
	the specified convergence threshold.

.. _analytical:

Analytical Case
================

#. Background

	This case is included to demonstrate a case which uses all of the common 
	variable types- normal, uniform, exponential, beta, and gamma.
	
	In addition to using all variable types, the values of the variables were 
	generated using distributions from MATLAB, and an equation was used to generate 
	the corresponding response. Since this example allows us to know the exact 
	values for responses when Monte-Carlo sampling the system, the correct Sobol 
	values in addition to the mean and variance can be found.

	Follow the instructions above, using whichever flags and options you are 
	interested in. For this example, unzip the folder ``analytical.zip`` 
	and execute ``PCE_Codes`` from the ``analytical`` directory.
	
	The equation used to generate the responses is given by
	
	.. math::
		:label: a
		
		f(x_0,x_1,x_2,x_3,x_4) = x_0 + 2x_1 +  3x_2+ 4x_3 + x_4 + x_0x_1 + x_4^2
	
	Using properties of the variance operator below,
	
	.. math::
		:label: b
	
		Var(aX) = a^2\sigma_{X}^2\\
	
	.. math::
		:label: c
		
		Var(X+Y) = \sigma_{X}^2 + \sigma_{Y}^2 + 2Cov(X,Y)\\
	
	.. math::
		:label: d
	
		Var(XY) = (E(X^2Y^2)-E(XY)^2)


	where :math:`Var` is the variance, :math:`Cov` is the covariance, and 
	:math:`E` is the expected value (mean), the expression for the variance of 
	the function :math:`f`, is given by:

	.. math::
		:label: var_ref
		
		Var(f) = \sigma_{x_0}^2 + 4\sigma_{x_1}^2 + 9\sigma_{x_2}^2  + 
		16\sigma_{x_3}^2 + \sigma_{x_4}^2 + (E(x_0^2x_1^2)-E(x_0x_1)^2)\\  
		+ (E(x_4^2x_4^2)-E(x_4x_4)^2) + 2Cov(x_0+x_1,x_0x_1) + 2Cov(x_4x_4,x_4)
		

	Variance for the distributions of the independent variables are given in 
	table below.
	
	Distributions for independent variables in the `analytical`_ example case
	
	+--------------+-------------------------------------------------------------------------------+-------------------------------------+--------------------------------------------------------------+
	| Distribution | Probability density                                                           | Mean                                | Variance                                                     |
	+==============+===============================================================================+=====================================+==============================================================+ 
	| normal       | :math:`\frac{1}{\sqrt{2\pi\sigma^2}}e^{\frac{-(x-\mu)^2}{2\sigma^2}}`         | :math:`\mu`                         | :math:`\sigma^2`                                             |
	+--------------+-------------------------------------------------------------------------------+-------------------------------------+--------------------------------------------------------------+
	| uniform      | :math:`\frac{1}{b-a}`                                                         | :math:`\frac{1}{2}(a+b)`            | :math:`\frac{1}{12}(b-a)^2`                                  |
	+--------------+-------------------------------------------------------------------------------+-------------------------------------+--------------------------------------------------------------+
	| exponential  | :math:`\lambda e^{-\lambda x}`                                                | :math:`\frac{1}{\lambda}`           | :math:`\frac{1}{\lambda^2}`                                  |
	+--------------+-------------------------------------------------------------------------------+-------------------------------------+--------------------------------------------------------------+
	| beta         | :math:`\frac{x^{\alpha-1}(1-x)^{\beta-1}}{B(\alpha,\beta)}`                   | :math:`\frac{\alpha}{\alpha+\beta}` | :math:`\frac{\alpha\beta}{(\alpha+\beta)^2(\alpha+\beta+1)}` |
	+--------------+-------------------------------------------------------------------------------+-------------------------------------+--------------------------------------------------------------+
	| gamma        | :math:`\frac{1}{\Gamma(\alpha)\theta^\alpha}x^{\alpha-1}e^{\frac{-x}{\theta}}`| :math:`\alpha\theta`                | :math:`\alpha\theta^2`                                       |
	+--------------+-------------------------------------------------------------------------------+-------------------------------------+--------------------------------------------------------------+

	Evaluating the variances for each of the independent parameters gives 
	:math:`Var(x_0)=0.25`, :math:`Var(x_1)=0.0208`, :math:`Var(x_2)=0.111`,
	:math:`Var(x_3)=0.0457`, :math:`Var(x_4)=0.25`. Substituting into equation 
	:eq:`var_ref` yields:

	.. math::

		Var(f) = 0.25 + 4(0.0208) + 9(0.111)   + 16(0.0457) + 0.25 + 1.0257 
		+ 1.2509 + 1.0825 + 0.9994

	Calculations for the covariance and expected quantity terms are left to the 
	reader. Simplifying yields: :math:`Var(f) = 6.674`. To determine the total 
	Sobol indices (sensitivities) for this analytical function, the total 
	variance is decomposed into individual variable contributions. For variables 
	that do not have any interaction components, i.e. :math:`x_0x_1`, the 
	decomposition is straight forward.  The Sobol indices for :math:`x_2,x_3` 
	and :math:`x_4` are given below.

	.. math::
		:label: f
	
		S_2 = \dfrac{ 9\sigma_{x_2}^2}{Var(f)} = 0.150

	.. math::
		:label: g
	
		S_3 = \dfrac{16\sigma_{x_3}^2}{Var(f)} = 0.110

	For :math:`x_4` the total Sobol index includes the variance contributions 
	from the quadratic terms as well.

	.. math::
		:label: h
		
		S_4 = \dfrac{\sigma_{x_4}^2 + (E(x_4^2x_4^2)-E(x_4x_4)^2) + 
		2Cov(x_4x_4,x_4)}{Var(f)} = 0.374

	Sobol indices for :math:`x_0` and :math:`x_1` calculations are slightly 
	more involved do to the interaction present. The variance contribution from 
	the interaction term must be proportioned based on the ratio of the variable 
	individual variances.

	.. math::
		:label: i
	
		S_0 = \dfrac{ \sigma_{x_0}^2 + 4\sigma_{x_1}^2 + 2Cov(x_0+x_1,x_0x_1) 
		+ (E(x_0^2x_1^2)-E(x_0x_1)^2) }{Var(f)} \dfrac{\sigma_{x_0}}
		{\sigma_{x_0}+\sigma_{x_1}} = 0.338

	.. math::
		:label: j
		
		S_1 = \dfrac{ \sigma_{x_0}^2 + 4\sigma_{x_1}^2 + 2Cov(x_0+x_1,x_0x_1) 
		+ (E(x_0^2x_1^2)-E(x_0x_1)^2) }{Var(f)} \dfrac{\sigma_{x_1}}
		{\sigma_{x_0}+\sigma_{x_1}} = 0.028
	

#. Outputs

	**Responses**
	
	+---------------------+--------------------+----------------------+
	|                     | UQPCE              | Monte-Carlo          |
	+=====================+====================+======================+ 
	| mean                | 9.8                | 9.7989               |
	+---------------------+--------------------+----------------------+
	| variance            | 6.6741             | 6.6727               |
	+---------------------+--------------------+----------------------+
	| confidence interval | [5.6205, 15.5860]  | [5.6365, 15.5405]    |
	+---------------------+--------------------+----------------------+
	
	This shows similar results as above. This case has data that has no units and 
	no physical meaning, and we still see that the results are similar between 
	using UQPCE and Monte-Carlo sampling the system.
	
	**Sobols**
	
	+---------+----------+--------------------+
	|         | UQPCE    | Analytical Results |
	+=========+==========+====================+ 
	| Sobol 0 | 0.3376   | 0.338              |
	+---------+----------+--------------------+
	| Sobol 1 | 0.0289   | 0.028              |
	+---------+----------+--------------------+
	| Sobol 2 | 0.1497   | 0.150              |
	+---------+----------+--------------------+
	| Sobol 3 | 0.1095   | 0.110              |
	+---------+----------+--------------------+
	| Sobol 4 | 0.3743   | 0.374              |
	+---------+----------+--------------------+

	Verifying the Sobol sensitivities is not something that can be done to a 
	system in which the underlying function is unknown. Since the underlying 
	function is known in this case, the Sobol indices can be calculated.
	
	From the Monte-Carlo samples (``10000000``), the Sobol indices are 
	calculated using an analytical variance calculation.
	
	|
	
	The user should get an output similar to the following if the ``--verify`` 
	flag is used with the verification files included for this case::
	
		Mean error between model and verification 2.3093e-14
			
	This value is similar to the mean error of the surrogate ``2.6272e-14`` 
	which suggests that the model is a good fit for the data.
	
.. _high order analytical: 

High Order Analytical Case
===========================

#. Background

	This case is included to demonstrate a case which uses all of the common 
	variable types- normal, uniform, exponential, beta, and gamma.
	
	In addition to using all variable types, the values of the variables were 
	generated using distributions from MATLAB, and an equation was used to generate 
	the corresponding response. Since this example allows us to know the exact 
	values for responses when Monte-Carlo sampling the system, the correct Sobol 
	values in addition to the mean and variance can be found.

	Follow the instructions above, using whichever flags and options you are 
	interested in. For this example, unzip the folder ``high_order_analytical.zip`` 
	and execute ``PCE_Codes`` from the ``high_order_analytical`` directory.
	
	The equation used to generate the responses is given by
	
	.. math::
		
		f(x_0,x_1,x_2,x_3,x_4) = 0.02x_0 + 0.03x_0^4 + 0.08x_0^5 - 0.05x_1 
		- 0.02x_1^4 + x_1^5 + x_2 + x_2^4 - 100x_2^5 - x_3 - x_3^4 + 1000x_3^5 
		- 0.09x_4 - 0.01x_4^4 + 0.01x_4^5
		
	.. 0.02.*x0 + 0.03.*x0.^4 + 0.08.*x0.^5 - 0.05.*x1 - 0.02.*x1.^4 + x1.^5 + x2 + x2.^4 - 100.*x2.^5 - x3 - x3.^4 + 1000.*x3.^5 - 0.09.*x4 - 0.01.*x4.^4 + 0.01.*x4.^5;
	
	Distributions for independent variables in the `high order analytical`_ example case
	
	+--------------+-------------------------------------------------------------------------------+-------------------------------------+--------------------------------------------------------------+
	| Distribution | Probability density                                                           | Mean                                | Variance                                                     |
	+==============+===============================================================================+=====================================+==============================================================+ 
	| normal       | :math:`\frac{1}{\sqrt{2\pi\sigma^2}}e^{\frac{-(x-\mu)^2}{2\sigma^2}}`         | :math:`\mu`                         | :math:`\sigma^2`                                             |
	+--------------+-------------------------------------------------------------------------------+-------------------------------------+--------------------------------------------------------------+
	| uniform      | :math:`\frac{1}{b-a}`                                                         | :math:`\frac{1}{2}(a+b)`            | :math:`\frac{1}{12}(b-a)^2`                                  |
	+--------------+-------------------------------------------------------------------------------+-------------------------------------+--------------------------------------------------------------+
	| exponential  | :math:`\lambda e^{-\lambda x}`                                                | :math:`\frac{1}{\lambda}`           | :math:`\frac{1}{\lambda^2}`                                  |
	+--------------+-------------------------------------------------------------------------------+-------------------------------------+--------------------------------------------------------------+
	| beta         | :math:`\frac{x^{\alpha-1}(1-x)^{\beta-1}}{B(\alpha,\beta)}`                   | :math:`\frac{\alpha}{\alpha+\beta}` | :math:`\frac{\alpha\beta}{(\alpha+\beta)^2(\alpha+\beta+1)}` |
	+--------------+-------------------------------------------------------------------------------+-------------------------------------+--------------------------------------------------------------+
	| gamma        | :math:`\frac{1}{\Gamma(\alpha)\theta^\alpha}x^{\alpha-1}e^{\frac{-x}{\theta}}`| :math:`\alpha\theta`                | :math:`\alpha\theta^2`                                       |
	+--------------+-------------------------------------------------------------------------------+-------------------------------------+--------------------------------------------------------------+

	Using the mean of each variable to hold the variables constant, the Sobols 
	are calculated using one-variable-at-a-time variable decomposition. The 
	means of the independent variables are given in the above table.

	Using the above equations for mean, the mean of each variable is given by 
	
	.. math::
		
			\overline{x_0}=2
		
	.. math::
			
			\overline{x_1}=1
			
	.. math::
			
			\overline{x_2}=\frac{1}{7} \approx 0.1429
			
	.. math::
			
			\overline{x_3}=\frac{0.6}{5.6} \approx 0.1071
			
	.. math::
			
			\overline{x_4}=2(0.7)=1.4
			

	The equation used to calculate each Sobol is shown below.

	.. math::
		S_0 = f(x_0, \overline{x_1}, \overline{x_2}, \overline{x_3}, \overline{x_4}, \overline{x_5})/f(x_0, x_1, x_2, x_3, x_4, x_5)
		
	.. math::
		S_1 = f(\overline{x_0}, x_1, \overline{x_2}, \overline{x_3}, \overline{x_4}, \overline{x_5})/f(x_0, x_1, x_2, x_3, x_4, x_5)
		
	.. math::
		S_2 = f(\overline{x_0}, \overline{x_1}, x_2, \overline{x_3}, \overline{x_4}, \overline{x_5})/f(x_0, x_1, x_2, x_3, x_4, x_5)

	.. math::
		S_3 = f(\overline{x_0}, \overline{x_1}, \overline{x_2}, x_3, \overline{x_4}, \overline{x_5})/f(x_0, x_1, x_2, x_3, x_4, x_5)
		
	.. math::
		S_4 = f(\overline{x_0}, \overline{x_1}, \overline{x_2}, \overline{x_3}, x_4, \overline{x_5})/f(x_0, x_1, x_2, x_3, x_4, x_5)
		

#. Outputs

	**Responses**
	
	+---------------------+---------------------+------------------+
	|                     | UQPCE               | Monte-Carlo      |
	+=====================+=====================+==================+ 
	| mean                | 11.409              | 11.403           |
	+---------------------+---------------------+------------------+
	| variance            | 418.27              | 421.18           |
	+---------------------+---------------------+------------------+
	| confidence interval | [0.2492, 40.507]    | [0.2542, 40.205] |
	+---------------------+---------------------+------------------+
	
	This shows similar results as above. This case has data that has no units and 
	no physical meaning, and we still see that the results are similar between 
	using UQPCE and Monte-Carlo sampling the system.
	
	**Sobols**
	
	+---------+----------+--------------------+
	|         | UQPCE    | Analytical Results |
	+=========+==========+====================+ 
	| Sobol 0 | 0.0399   | 0.0407             |
	+---------+----------+--------------------+
	| Sobol 1 | 0.1504   | 0.1539             |
	+---------+----------+--------------------+
	| Sobol 2 | 0.2993   | 0.2863             |
	+---------+----------+--------------------+
	| Sobol 3 | 0.3094   | 0.3150             |
	+---------+----------+--------------------+
	| Sobol 4 | 0.2011   | 0.2037             |
	+---------+----------+--------------------+

	Verifying the Sobol sensitivities is not something that can be done to a 
	system in which the underlying function is unknown. Since the underlying 
	function is known in this case, the Sobol indices can be calculated.
	
	From the Monte-Carlo samples (``50000000``), the Sobol indices are 
	calculated using an analytical variance calculation.
	
	|
	
	The user should get an output similar to the following if the ``--verify`` 
	flag is used with the verification files included for this case::
	
		Mean error between model and verification 2.7579e-09
			
	This value is similar to the mean error of the surrogate ``2.9757e-09`` 
	which suggests that the model is a good fit for the data.
	
	
.. _general:
	
User Input Variable Case
=========================

#. Background

	This case is included to demonstrate the accuracy and flexibility of 
	inputting variables according to their equation instead of variable type.
	
	Follow the instructions above, using whichever flags and options you are 
	interested in. For this example, unzip the folder 
	``general_variable_analytical.zip`` and execute ``PCE_Codes`` from the 
	``general_variable_analytical`` directory.

	.. note::
	
		Using the equation approach for inputting a variable of one of the 
		variable types (``normal``, ``uniform``, ``beta``, ``exponential``, and 
		``gamma``) is not recommended when running the program. It will give you 
		equivalent outputs, but the equation-based approach is much slower than 
		the using the variable types.

	The equation used to generate the responses is given by :eq:`a`.

	Distributions for independent variables in the `general`_ variable example case
	
	+------------------+-----------------------------------------------------------------------------------------+-------------------------------------+------------------------------------------------------------------------------+
	| Distribution     | Probability density                                                                     | Mean                                | Variance                                                                     |
	+==================+=========================================================================================+=====================================+==============================================================================+ 
	| Weibull          | :math:`\frac{b}{a} \Big(\frac{x}{a}\Big)^{b-1} e^{-(\frac{x}{a})^{b}}`                  | :math:`a\ \Gamma(1+\frac{1}{b})`    | :math:`a^2\Big(\Gamma(1+\frac{2}{b})-\Big(\Gamma(1+\frac{1}{b})\Big)^2\Big)` |
	+------------------+-----------------------------------------------------------------------------------------+-------------------------------------+------------------------------------------------------------------------------+
	| inverse Gaussian | :math:`\sqrt{\frac{\lambda}{2\pi x^{3}}} e^{-\frac{\lambda}{2\mu^{2}x}(x\ -\ \mu)^{2}}` | :math:`\mu`                         | :math:`\frac{\mu^3}{\lambda}`                                                |
	+------------------+-----------------------------------------------------------------------------------------+-------------------------------------+------------------------------------------------------------------------------+
	| trapezoidal      | :math:`\ m \ x`                                                                         | :math:`\frac{m}{3}`                 | :math:`\frac{m}{4}-\frac{m^2}{9}`                                            |
	+------------------+-----------------------------------------------------------------------------------------+-------------------------------------+------------------------------------------------------------------------------+
	| sinusoidal       | :math:`c\ sin(x)`                                                                       | :math:`\pi\ c`                      | :math:`\Big(\pi^2-4\Big)c-\pi^2c^2`                                          |
	+------------------+-----------------------------------------------------------------------------------------+-------------------------------------+------------------------------------------------------------------------------+
	| normal           | :math:`\frac{1}{\sqrt{2\pi\sigma^2}}e^{\frac{-(x-\mu)^2}{2\sigma^2}}`                   | :math:`\mu`                         | :math:`\sigma^2`                                                             |
	+------------------+-----------------------------------------------------------------------------------------+-------------------------------------+------------------------------------------------------------------------------+

	Using the mean of each variable to hold the variables constant, the Sobols 
	are calculated using one-variable-at-a-time variable decomposition. The 
	means of the independent variables are given in the above table.

	Using the above equations for mean, the mean of each variable is given by 
	
	.. math::
		
		\overline{x_0}=2\ \Gamma\bigg(1+\frac{1}{3}\bigg) \approx 1.7860
		
	.. math::
			
			\overline{x_1}=1
			
	.. math::
			
			\overline{x_2}=\frac{2}{3} \approx 0.6667
			
	.. math::
			
			\overline{x_3}=(0.5)\pi \approx 1.5708
			
	.. math::
			
			\overline{x_4}=1.5
			

	The equation used to calculate each Sobol is shown below.

	.. math::
		S_0 = f(x_0, \overline{x_1}, \overline{x_2}, \overline{x_3}, \overline{x_4}, \overline{x_5})/f(x_0, x_1, x_2, x_3, x_4, x_5)
		
	.. math::
		S_1 = f(\overline{x_0}, x_1, \overline{x_2}, \overline{x_3}, \overline{x_4}, \overline{x_5})/f(x_0, x_1, x_2, x_3, x_4, x_5)
		
	.. math::
		S_2 = f(\overline{x_0}, \overline{x_1}, x_2, \overline{x_3}, \overline{x_4}, \overline{x_5})/f(x_0, x_1, x_2, x_3, x_4, x_5)

	.. math::
		S_3 = f(\overline{x_0}, \overline{x_1}, \overline{x_2}, x_3, \overline{x_4}, \overline{x_5})/f(x_0, x_1, x_2, x_3, x_4, x_5)
		
	.. math::
		S_4 = f(\overline{x_0}, \overline{x_1}, \overline{x_2}, \overline{x_3}, x_4, \overline{x_5})/f(x_0, x_1, x_2, x_3, x_4, x_5)
		

#. Outputs

	**Responses**

	+---------------------+--------------------+----------------------+
	|                     | UQPCE              | Monte-Carlo          |
	+=====================+====================+======================+
	| mean                | 17.645             | 17.643               |
	+---------------------+--------------------+----------------------+
	| variance            | 15.225             | 15.219               |
	+---------------------+--------------------+----------------------+
	| confidence interval | [10.591, 25.657]   | [10.731, 25.864]     |
	+---------------------+--------------------+----------------------+
	
	**Sobols**
	
	+---------+----------+--------------------+
	|         | UQPCE    | Analytical Results |
	+=========+==========+====================+ 
	| Sobol 0 | 0.11882  | 0.1117             |
	+---------+----------+--------------------+
	| Sobol 1 | 0.32008  | 0.3167             |
	+---------+----------+--------------------+
	| Sobol 2 | 0.03254  | 0.0331             |
	+---------+----------+--------------------+
	| Sobol 3 | 0.4867   | 0.4958             |
	+---------+----------+--------------------+
	| Sobol 4 | 0.04186  | 0.0427             |
	+---------+----------+--------------------+
	
	From the Monte-Carlo samples (``10000000``), the Sobol indices are 
	calculated using one-variable-at-a-time variance decomposition.

	This case was run with ``order = 2``, which is the lowest order that gives 
	us reliable results in this case.

	If the ``--verify`` flag is used, you will see output similar to below::

		Mean error between model and verification 4.2751e-14
		
	This value is similar to the mean error of the surrogate ``2.8777e-14`` 
	which suggests that the model is a good fit for the data.

.. _interval:

Interval Case
==============

#. Background

	This case is included to demonstrate the accuracy and flexibility of 
	inputting variables according to their equation instead of variable type.
	
	Follow the instructions above, using whichever flags and options you are 
	interested in. For this example, unzip the folder ``interval_variable.zip`` 
	and execute ``PCE_Codes`` from the ``interval_variable`` directory.

	The equation used to generate the responses is given by

	.. math::
		f(x_0,x_1,x_2,x_3,x_4,x_5) = x_0 + 2x_1 + 3x_2+ 4x_3 + x_4 + x_0x_1
			+ x_4^2 + 3x_5x_2

	Variance for the distributions of the independent variables are given in 
	table below.
	
	Distributions for independent variables in the `interval`_ variable example case

	+--------------+-----------------------------------------------------------------------------------------------------------------------------------------------------+---------------------------------------------+--------------------------------------------------------------------+
	| Distribution | Probability density                                                                                                                                 | Mean                                        | Variance                                                           |
	+==============+=====================================================================================================================================================+=============================================+====================================================================+ 
	| exponential  | :math:`\lambda e^{-\lambda (x\ -\ a)}`                                                                                                              | :math:`a+\frac{1}{\lambda}`                 | :math:`\frac{1}{\lambda^2}`                                        |
	+--------------+-----------------------------------------------------------------------------------------------------------------------------------------------------+---------------------------------------------+--------------------------------------------------------------------+
	| beta         | :math:`\frac{1}{b-a}\frac{\Gamma(\alpha+\beta)}{\Gamma(\alpha)\Gamma(\beta)}\Big(\frac{x-a}{b-a}\Big)^{\alpha-1}\Big(\frac{b-x}{b-a}\Big)^{\beta-1}`| :math:`a+(b-a)(\frac{\alpha}{\alpha+\beta})`| :math:`\frac{(b-a)^2\alpha\beta}{(\alpha+\beta)^2(\alpha+\beta+1)}`|
	+--------------+-----------------------------------------------------------------------------------------------------------------------------------------------------+---------------------------------------------+--------------------------------------------------------------------+
	| gamma        | :math:`\frac{1}{\Gamma(\alpha)\theta^{\alpha}}(x-a)^{\alpha-1}e^{-\frac{(x-a)}{\theta}}`                                                            | :math:`a+\alpha\theta`                      | :math:`\alpha\theta^2`                                             |
	+--------------+-----------------------------------------------------------------------------------------------------------------------------------------------------+---------------------------------------------+--------------------------------------------------------------------+

	Using the mean of each variable to hold the variables constant, the Sobols 
	are calculated using one-variable-at-a-time variable decomposition. The 
	means of the independent variables are given in the above table.

	Using the above equations for mean, the mean of each variable is given by 
	
	.. math::
		
		\overline{x_0}=3+\frac{1}{0.25}=7
		
	.. math::
			
			\overline{x_1}=-2+\frac{1}{3} \approx -1.6667
			
	.. math::
			
			\overline{x_2}=3+(7-3)\frac{2}{(2+4)} \approx 4.3333
			
	.. math::
			
			\overline{x_3}=-1+(0-(-1))\frac{0.5}{(0.5+2)} \approx -0.8
			
	.. math::
			
			\overline{x_4}=1+(1)(0.5)=1.5
			
	.. math::
			
			\overline{x_5}=3+(3)(2)=9

	The equation used to calculate each Sobol is shown below.

	.. math::
		S_0 = f(x_0, \overline{x_1}, \overline{x_2}, \overline{x_3}, \overline{x_4}, \overline{x_5})/f(x_0, x_1, x_2, x_3, x_4, x_5)
		
	.. math::
		S_1 = f(\overline{x_0}, x_1, \overline{x_2}, \overline{x_3}, \overline{x_4}, \overline{x_5})/f(x_0, x_1, x_2, x_3, x_4, x_5)
		
	.. math::
		S_2 = f(\overline{x_0}, \overline{x_1}, x_2, \overline{x_3}, \overline{x_4}, \overline{x_5})/f(x_0, x_1, x_2, x_3, x_4, x_5)

	.. math::
		S_3 = f(\overline{x_0}, \overline{x_1}, \overline{x_2}, x_3, \overline{x_4}, \overline{x_5})/f(x_0, x_1, x_2, x_3, x_4, x_5)
		
	.. math::
		S_4 = f(\overline{x_0}, \overline{x_1}, \overline{x_2}, \overline{x_3}, x_4, \overline{x_5})/f(x_0, x_1, x_2, x_3, x_4, x_5)
		
	.. math::
		S_5 = f(\overline{x_0}, \overline{x_1}, \overline{x_2}, \overline{x_3}, \overline{x_4}, x_5)/f(x_0, x_1, x_2, x_3, x_4, x_5)


#. Outputs

	**Responses**

	+---------------------+--------------------+----------------------+
	|                     | UQPCE              | Monte-Carlo          |
	+=====================+====================+======================+
	| mean                | 123.6              | 122.80               |
	+---------------------+--------------------+----------------------+
	| variance            | 2567.5             | 2564.62              |
	+---------------------+--------------------+----------------------+
	| confidence interval | [54.931, 249.54]   | [53.56, 247.52]      |
	+---------------------+--------------------+----------------------+
	
	**Sobols**
	
	+---------+----------+--------------------+
	|         | UQPCE    | Analytical Results |
	+=========+==========+====================+ 
	| Sobol 0 | 0.0033   | 0.0028             |
	+---------+----------+--------------------+
	| Sobol 1 | 0.0041   | 0.0036             |
	+---------+----------+--------------------+
	| Sobol 2 | 0.1952   | 0.1823             |
	+---------+----------+--------------------+
	| Sobol 3 | 0.0011   | 0.0003             |
	+---------+----------+--------------------+
	| Sobol 4 | 0.0025   | 0.0026             |
	+---------+----------+--------------------+
	| Sobol 5 | 0.7938   | 0.8084             |
	+---------+----------+--------------------+

	From the Monte-Carlo samples (``100000000``), the Sobol indices are 
	calculated using an analytical variance calculation.

	This case was run with ``order = 2``, which is the lowest order that gives 
	us reliable results in this case.

	If the ``--verify`` flag is used, you will see output similar to below::

		Mean error between model and verification 0.014425
		
	This value is similar to the mean error of the surrogate ``0.0044884`` 
	which suggests that the model is a good fit for the data.

